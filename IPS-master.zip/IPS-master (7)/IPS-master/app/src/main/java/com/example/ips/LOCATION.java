package com.example.ips;

public class LOCATION {
    public float longtitude;
    public float latitude;

    public LOCATION(float longtitude, float latitude) {
        this.longtitude = longtitude;
        this.latitude = latitude ;
    }
}
