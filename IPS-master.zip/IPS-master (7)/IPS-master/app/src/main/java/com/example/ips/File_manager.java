package com.example.ips;

import static android.content.ContentValues.TAG;

import android.content.pm.PackageManager;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class File_manager {
    private List<String> filePaths = new ArrayList<>();
    public void writeFile()
    {

        // Bytes of Data from Trajectory
        byte[] bytes = Switch.data_collector_top.TrajectoryTop.build().toByteArray();
/*
        // Create and Write Data to Binary File, store in Downloads

            File directory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if(!directory.exists()){
                directory.mkdirs();
            }
            String filename = "trajectorydata_" + ".bin";
            File trajectorydata = new File(directory, filename);
*/

        File trajectorydata = null;
        try {
            trajectorydata = createBinaryFile();
        } catch (IOException e) {
            e.printStackTrace();
        }

        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(trajectorydata);
            fos.write(bytes);
            fos.flush();
            fos.close();

            // Store the path of the created file
            String filePath = trajectorydata.getAbsolutePath();
            filePaths.add("debug lines");
            filePaths.add(filePath);
        } catch (IOException ex) {
            ex.printStackTrace();
            Log.e(TAG, "IOException occurred: " + ex.getMessage());
        }
    }

    String currentBinaryPath;
    String imageFileName;
    private File createBinaryFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("_ddMMyy_HHmmss").format(new Date());
        imageFileName = "Trajectory_" + timeStamp;
        //String imageFileName = "test6";
        File storageDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);

        File trajectory = new File(storageDir + "/" + File.separator + imageFileName + ".bin");
        trajectory.createNewFile();

        // Save a file: path for use with ACTION_VIEW intents
        currentBinaryPath = trajectory.getAbsolutePath();
        return trajectory;
    }
}
